﻿namespace Lab6UnitTest;
using Lab62910;
using Lab62910.Data;
using Lab62910.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using static System.Reflection.Metadata.BlobBuilder;

[TestClass]
public class BookServiceTests
{
    private BookService bookService;

    [TestInitialize]
    public void Setup()

    { 
        bookService = new BookService();
    }

    [TestMethod]
    public void TestAddBook()
    {
        // Arrange
        var book = new Book { Title = "Book 1", Author = "Author 1", ISBN = "123456" };

        // Act
        bookService.AddBook(book);

        // Assert
        var books = bookService.GetBooks();
        Assert.AreEqual(1, books.Count);
        Assert.AreEqual(book.Title, books[0].Title);
        Assert.AreEqual(book.Author, books[0].Author);
        Assert.AreEqual(book.ISBN, books[0].ISBN);
        Assert.AreEqual(1, books[0].Id);
    }

    [TestMethod]
    public void TestEditBook()
    {
        // Arrange
        var book = new Book { Title = "Book 1", Author = "Author 1", ISBN = "123456" };
        bookService.AddBook(book);
        var updatedBook = new Book { Id = 1, Title = "Updated Book 1", Author = "Updated Author 1", ISBN = "123456" };

        // Act
        bookService.EditBook(updatedBook);

        // Assert
        var books = bookService.GetBooks();
        Assert.AreEqual(1, books.Count);
        Assert.AreEqual("Updated Book 1", books[0].Title);
        Assert.AreEqual("Updated Author 1", books[0].Author);
    }

    [TestMethod]
    public void TestDeleteBook()
    {
        // Arrange
        var book = new Book { Title = "Book 1", Author = "Author 1", ISBN = "123456" };
        bookService.AddBook(book);

        // Act
        bookService.DeleteBook(1);

        // Assert
        var books = bookService.GetBooks();
        Assert.AreEqual(0, books.Count);
    }

    [TestMethod]
    public void TestGetBookByISBN()
    {
        // Arrange
        var book1 = new Book { Title = "Book 1", Author = "Author 1", ISBN = "123456" };
        var book2 = new Book { Title = "Book 2", Author = "Author 2", ISBN = "654321" };
        bookService.AddBook(book1);
        bookService.AddBook(book2);

        // Act
        var foundBook = bookService.GetBookByISBN("654321");

        // Assert
        Assert.IsNotNull(foundBook);
        Assert.AreEqual("Book 2", foundBook.Title);
        Assert.AreEqual("Author 2", foundBook.Author);
        Assert.AreEqual("654321", foundBook.ISBN);
    }
}